package com.example.customai

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.util.Base64
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.apache.poi.xwpf.usermodel.XWPFDocument
import org.apache.poi.hwpf.HWPFDocument

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF151923)
private val Panel2 = Color(0xFF202635)
private val Accent = Color(0xFF8B7CFF)
private val MainText = Color(0xFFF4F5FA)
private val Muted = Color(0xFF9AA3B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Panel)) { CustomAiApp() } }
    }
}

data class ChatMessage(val text: String, val isUser: Boolean)
data class PickedFile(val uri: Uri, val name: String, val mime: String, val size: Long)

@Composable
fun CustomAiApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("custom_ai", 0) }
    var endpoint by remember { mutableStateOf(prefs.getString("endpoint", "https://your-server.example/v1/chat/completions") ?: "") }
    var apiKey by remember { mutableStateOf(decryptKey(prefs.getString("key_enc", null))) }
    var model by remember { mutableStateOf(prefs.getString("model", "your-model") ?: "your-model") }
    var headersJson by remember { mutableStateOf(prefs.getString("headers", "{}") ?: "{}") }
    var bearerAuth by remember { mutableStateOf(prefs.getBoolean("bearer_auth", true)) }
    var testLoading by remember { mutableStateOf(false) }
    var testStatus by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>() }
    val files = remember { mutableStateListOf<PickedFile>() }
    LaunchedEffect(Unit) {
        val saved = prefs.getString("history", "[]") ?: "[]"
        try {
            val array = JSONArray(saved)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                messages.add(ChatMessage(item.getString("text"), item.getBoolean("user")))
            }
        } catch (_: Exception) { }
    }
    LaunchedEffect(messages.size) {
        val array = JSONArray()
        messages.forEach { array.put(JSONObject().put("text", it.text).put("user", it.isUser)) }
        prefs.edit().putString("history", array.toString()).apply()
    }
    val scope = rememberCoroutineScope()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            var name = "Файл"
            var size = 0L
            cursor?.use { if (it.moveToFirst()) {
                val ni = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (ni >= 0) name = it.getString(ni) ?: name
                val si = it.getColumnIndex(OpenableColumns.SIZE); if (si >= 0) size = it.getLong(si)
            } }
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            if (mime.startsWith("image/") || mime == "application/pdf" || name.endsWith(".docx", true) || name.endsWith(".doc", true) || name.endsWith(".txt", true)) {
                if (files.none { it.uri == uri }) files.add(PickedFile(uri, name, mime, size))
            } else error = "Поддерживаются изображения, PDF, DOCX и TXT"
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Row(Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).background(Accent.copy(alpha = .18f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                    Text("✦", color = Accent, fontSize = 22.sp)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text("Custom AI", color = MainText, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(if (model.isBlank()) "Модель не выбрана" else model, color = Muted, fontSize = 11.sp)
                }
                IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Настройки", tint = Muted) }
                IconButton(onClick = { messages.clear(); files.clear(); error = "" }) { Icon(Icons.Default.Add, "Новый чат", tint = Muted) }
            }
            if (messages.isEmpty()) {
                Spacer(Modifier.weight(1f))
                Text("Ваш AI. Ваши правила.", color = MainText, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Подключите собственный API и начните диалог. Можно добавлять документы и изображения.", color = Muted, fontSize = 14.sp, lineHeight = 21.sp)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Suggestion("Объясни тему") { input = "Объясни мне тему простыми словами" }
                    Suggestion("Проанализируй файл") { input = "Проанализируй прикреплённый файл" }
                }
                Spacer(Modifier.weight(1f))
            } else {
                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(messages) { msg ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start) {
                            Column(Modifier.widthIn(max = 310.dp).background(if (msg.isUser) Color(0xFF292545) else Panel, RoundedCornerShape(18.dp)).padding(14.dp)) {
                                Text(msg.text, color = MainText, fontSize = 14.sp, lineHeight = 21.sp)
                            }
                        }
                    }
                    if (loading) item { Text("AI печатает…", color = Muted, fontSize = 13.sp) }
                }
            }
            if (error.isNotBlank()) Text(error, color = Color(0xFFFF8C8C), fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            if (files.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    files.forEach { file ->
                        Row(Modifier.background(Panel2, RoundedCornerShape(10.dp)).padding(start = 9.dp, end = 4.dp, top = 5.dp, bottom = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(file.name.take(16), color = MainText, fontSize = 11.sp)
                            IconButton(onClick = { files.remove(file) }, modifier = Modifier.size(22.dp)) { Icon(Icons.Default.Delete, null, tint = Muted, modifier = Modifier.size(14.dp)) }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 14.dp).background(Panel, RoundedCornerShape(23.dp)).padding(8.dp), verticalAlignment = Alignment.Bottom) {
                IconButton(onClick = { picker.launch(arrayOf("image/*", "application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword", "text/plain")) }, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.AttachFile, "Прикрепить файл", tint = Muted)
                }
                BasicTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f).padding(horizontal = 8.dp, vertical = 11.dp), textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 14.sp), cursorBrush = androidx.compose.ui.graphics.SolidColor(Accent), decorationBox = { inner ->
                    Box { if (input.isEmpty()) Text("Напишите сообщение…", color = Muted, fontSize = 14.sp); inner() }
                })
                IconButton(onClick = {
                    if (!loading && (input.isNotBlank() || files.isNotEmpty())) {
                        if (endpoint.isBlank() || model.isBlank()) { showSettings = true; error = "Сначала настройте API и модель" }
                        else {
                            val prompt = input.trim()
                            val selected = files.toList()
                            messages.add(ChatMessage(buildString { append(prompt.ifBlank { "Проанализируй прикреплённые файлы" }); if (selected.isNotEmpty()) { append("\n"); append(selected.joinToString { it.name }) } }, true))
                            input = ""; files.clear(); error = ""; loading = true
                            scope.launch {
                                try {
                                    val answer = withContext(Dispatchers.IO) { sendToApi(context, endpoint, apiKey, model, headersJson, bearerAuth, messages.dropLast(1).toList() + ChatMessage(prompt, true), selected) }
                                    messages.add(ChatMessage(answer, false))
                                } catch (e: Exception) { error = e.message ?: "Ошибка запроса"; messages.add(ChatMessage("Не удалось получить ответ. Проверьте настройки API и подключение.", false)) }
                                finally { loading = false }
                            }
                        }
                    }
                }, enabled = !loading && (input.isNotBlank() || files.isNotEmpty()), modifier = Modifier.size(40.dp).background(Accent, CircleShape)) {
                    Icon(Icons.Default.ArrowUpward, "Отправить", tint = Color.White)
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(onDismissRequest = { showSettings = false }, containerColor = Panel, title = { Text("Подключение API", color = MainText, fontWeight = FontWeight.Bold) }, text = {
            Column(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SettingField("Полный URL endpoint", endpoint, { endpoint = it }, "https://server.example/v1/chat/completions")
                SettingField("Название модели", model, { model = it }, "Например: llama-3.1-70b")
                SettingField("API Key / Token", apiKey, { apiKey = it }, "Необязательно", true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Передавать ключ как Bearer Token", color = MainText, fontSize = 13.sp)
                        Text("Заголовок Authorization: Bearer …", color = Muted, fontSize = 10.sp)
                    }
                    Switch(checked = bearerAuth, onCheckedChange = { bearerAuth = it })
                }
                Text("Дополнительные HTTP-заголовки (JSON)", color = Muted, fontSize = 11.sp)
                OutlinedTextField(value = headersJson, onValueChange = { headersJson = it }, modifier = Modifier.fillMaxWidth().heightIn(min = 76.dp), placeholder = { Text("{\n  \"X-API-Key\": \"token\"\n}", fontSize = 11.sp) }, textStyle = androidx.compose.ui.text.TextStyle(color = MainText, fontSize = 12.sp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Panel2, focusedTextColor = MainText, unfocusedTextColor = MainText))
                Text("Протокол: OpenAI-compatible Chat Completions. Сервер должен принимать POST JSON с полями model и messages и возвращать choices[0].message.content. Ключ шифруется на устройстве.", color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
                if (testStatus.isNotBlank()) Text(testStatus, color = if (testStatus.startsWith("Успешно")) Color(0xFF80D6A5) else Color(0xFFFFA0A0), fontSize = 12.sp)
                OutlinedButton(onClick = {
                    if (endpoint.isBlank() || model.isBlank()) { testStatus = "Укажите URL и модель" }
                    else {
                        testLoading = true; testStatus = "Проверяем подключение…"
                        scope.launch {
                            try {
                                val result = withContext(Dispatchers.IO) { sendToApi(context, endpoint.trim(), apiKey.trim(), model.trim(), headersJson, bearerAuth, listOf(ChatMessage("Ответь одним словом: OK", true)), emptyList()) }
                                testStatus = "Успешно: сервер ответил (${result.take(80)})"
                            } catch (e: Exception) { testStatus = "Ошибка: ${e.message?.take(180) ?: "не удалось подключиться"}" }
                            finally { testLoading = false }
                        }
                    }
                }, enabled = !testLoading, modifier = Modifier.fillMaxWidth()) { Text(if (testLoading) "Проверка…" else "Проверить подключение") }
            }
        }, confirmButton = { TextButton(onClick = {
            try {
                JSONObject(headersJson)
                prefs.edit().putString("endpoint", endpoint.trim()).putString("key_enc", encryptKey(apiKey.trim())).remove("key").putString("model", model.trim()).putString("headers", headersJson).putBoolean("bearer_auth", bearerAuth).apply()
                showSettings = false; testStatus = ""
            } catch (_: Exception) { testStatus = "Дополнительные заголовки должны быть корректным JSON-объектом" }
        }) { Text("Сохранить", color = Accent) } }, dismissButton = { TextButton(onClick = { showSettings = false; testStatus = "" }) { Text("Отмена", color = Muted) } })
    }
}

@Composable
fun Suggestion(text: String, onClick: () -> Unit) { Surface(onClick = onClick, color = Panel, shape = RoundedCornerShape(14.dp)) { Text(text, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp)) } }

@Composable
fun SettingField(label: String, value: String, onChange: (String) -> Unit, placeholder: String, secret: Boolean = false) {
    Column {
        Text(label, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 5.dp))
        OutlinedTextField(value = value, onValueChange = onChange, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text(placeholder, fontSize = 12.sp) }, visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None, keyboardOptions = if (secret) KeyboardOptions(keyboardType = KeyboardType.Password) else KeyboardOptions.Default, colors = OutlinedTextFieldDefaults.colors(focusedTextColor = MainText, unfocusedTextColor = MainText, focusedBorderColor = Accent, unfocusedBorderColor = Panel2, cursorColor = Accent))
    }
}

private fun sendToApi(context: android.content.Context, endpoint: String, key: String, model: String, headersJson: String, bearerAuth: Boolean, history: List<ChatMessage>, files: List<PickedFile>): String {
    val messagesJson = JSONArray()
    history.takeLast(20).forEachIndexed { index, message ->
        val role = if (message.isUser) "user" else "assistant"
        val obj = JSONObject().put("role", role)
        if (message.isUser && index == history.lastIndex && files.isNotEmpty()) {
            val content = JSONArray()
            content.put(JSONObject().put("type", "text").put("text", message.text.ifBlank { "Проанализируй прикреплённые файлы" }))
            files.forEach { file ->
                if (file.mime.startsWith("image/")) {
                    val bytes = context.contentResolver.openInputStream(file.uri)?.use { it.readBytes() } ?: byteArrayOf()
                    require(bytes.size <= 12 * 1024 * 1024) { "Изображение слишком большое (максимум 12 МБ)" }
                    val data = "data:${file.mime};base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
                    content.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", data)))
                } else {
                    val text = extractText(context, file)
                    content.put(JSONObject().put("type", "text").put("text", "\n\n--- Файл: ${file.name} ---\n$text\n--- Конец файла ---"))
                }
            }
            obj.put("content", content)
        } else obj.put("content", message.text)
        messagesJson.put(obj)
    }
    val body = JSONObject().put("model", model).put("messages", messagesJson).put("temperature", 0.7).toString()
    val requestBuilder = Request.Builder().url(endpoint).post(body.toRequestBody("application/json; charset=utf-8".toMediaType())).header("Content-Type", "application/json")
    if (key.isNotBlank() && bearerAuth) requestBuilder.header("Authorization", "Bearer $key")
    val extraHeaders = try { JSONObject(headersJson) } catch (_: Exception) { throw Exception("Дополнительные заголовки должны быть JSON-объектом") }
    val headerKeys = extraHeaders.keys()
    while (headerKeys.hasNext()) {
        val headerName = headerKeys.next()
        val headerValue = extraHeaders.optString(headerName)
        if (headerName.isNotBlank() && headerValue.isNotBlank()) requestBuilder.header(headerName, headerValue)
    }
    val client = OkHttpClient.Builder().callTimeout(120, TimeUnit.SECONDS).build()
    client.newCall(requestBuilder.build()).execute().use { response ->
        val responseText = response.body?.string().orEmpty()
        if (!response.isSuccessful) throw Exception("API ${response.code}: ${responseText.take(500)}")
        val json = JSONObject(responseText)
        val content = json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").opt("content")
        return when (content) {
            is String -> content
            is JSONArray -> buildString { for (i in 0 until content.length()) { val part = content.optJSONObject(i); if (part != null) append(part.optString("text", "")) } }.ifBlank { "Модель вернула пустой ответ" }
            else -> "Пустой ответ от модели"
        }
    }
}

private fun extractText(context: android.content.Context, file: PickedFile): String {
    val bytes = context.contentResolver.openInputStream(file.uri)?.use { it.readBytes() } ?: return "Не удалось прочитать файл"
    require(bytes.size <= 15 * 1024 * 1024) { "Файл ${file.name} больше 15 МБ" }
    return when {
        file.mime == "application/pdf" || file.name.endsWith(".pdf", true) -> {
            val doc = PDDocument.load(bytes)
            try { PDFTextStripper().getText(doc).take(60000) } finally { doc.close() }
        }
        file.name.endsWith(".docx", true) -> XWPFDocument(bytes.inputStream()).use { doc -> doc.paragraphs.joinToString("\n") { it.text }.take(60000) }
        file.name.endsWith(".doc", true) -> HWPFDocument(bytes.inputStream()).use { doc -> doc.range.text().take(60000) }
        file.name.endsWith(".txt", true) || file.mime.startsWith("text/") -> bytes.toString(Charsets.UTF_8).take(60000)
        else -> "Формат файла не поддерживается для извлечения текста"
    }
}


private const val KEY_ALIAS = "custom_ai_api_key_v1"

private fun getSecretKey(): SecretKey {
    val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
    val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
    if (existing != null) return existing
    val generator = KeyGenerator.getInstance("AES", "AndroidKeyStore")
    val spec = android.security.keystore.KeyGenParameterSpec.Builder(
        KEY_ALIAS,
        android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
    ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
        .setRandomizedEncryptionRequired(true)
        .build()
    generator.init(spec)
    return generator.generateKey()
}

private fun encryptKey(value: String): String {
    if (value.isBlank()) return ""
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
    val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
    return Base64.encodeToString(cipher.iv + encrypted, Base64.NO_WRAP)
}

private fun decryptKey(value: String?): String {
    if (value.isNullOrBlank()) return ""
    return try {
        val bytes = Base64.decode(value, Base64.NO_WRAP)
        val iv = bytes.copyOfRange(0, 12)
        val encrypted = bytes.copyOfRange(12, bytes.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), GCMParameterSpec(128, iv))
        String(cipher.doFinal(encrypted), Charsets.UTF_8)
    } catch (_: Exception) { "" }
}
