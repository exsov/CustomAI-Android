# Сборка CustomAI APK через GitHub Actions без Android Studio

## Что потребуется
- Аккаунт GitHub.
- Файл `CustomAI-Android-Project.zip`.
- Браузер.

## Настройка репозитория
1. Создайте новый репозиторий GitHub (например, `CustomAI-Android`).
2. Загрузите в корень репозитория файл `CustomAI-Android-Project.zip`.
3. Создайте файл `.github/workflows/build-apk.yml`.
4. Скопируйте в него содержимое файла `github-workflow/build-apk.yml` из этого комплекта. Если вы распаковали архив на компьютере, путь к шаблону будет `CustomAI/github-workflow/build-apk.yml`.
5. Сохраните файл (Commit changes).

## Запуск
1. Откройте вкладку **Actions** репозитория.
2. Выберите **Build CustomAI APK**.
3. Нажмите **Run workflow** → **Run workflow**.
4. Дождитесь зелёной галочки у запуска.
5. Откройте завершённый запуск и найдите раздел **Artifacts** внизу страницы.
6. Скачайте `CustomAI-debug-apk.zip`, распакуйте его — внутри будет `app-debug.apk`.
7. Перенесите APK на Android и установите. Android может попросить разрешить установку приложений из выбранного источника.

## Важно
- Workflow собирает debug APK для тестирования, не подписанный release APK для публикации в Google Play.
- В репозитории должен лежать именно файл с точным именем `CustomAI-Android-Project.zip` в корне.
- Секретные API-ключи не добавляйте в GitHub: вводите их непосредственно в приложении.
- Сборка требует интернет-доступа GitHub Actions к репозиториям Gradle и Android SDK.
